# Saku Harian

Aplikasi pencatatan keuangan dengan Java, tersedia sebagai aplikasi **Android** dan **desktop**. Catatan disimpan secara lokal: Android menyimpannya di perangkat, sedangkan aplikasi desktop menyimpannya di folder pengguna komputer.

## Fitur

- Mencatat pemasukan dan pengeluaran beserta kategori dan tanggal.
- Melihat ringkasan pemasukan, pengeluaran, dan anggaran bulanan.
- Memantau pengeluaran selama tujuh hari terakhir.
- Memfilter, mengubah, dan menghapus transaksi.
- Mengekspor seluruh catatan ke file CSV.

## Menjalankan aplikasi desktop di Apache NetBeans

1. Buka Apache NetBeans dan pilih **File > Open Project**.
2. Pilih folder **`desktop`** di dalam folder proyek ini. Folder tersebut berisi proyek Maven desktop, sedangkan folder utama adalah proyek Android/Gradle.
3. Tunggu NetBeans memuat proyek Maven, lalu buka **Source Packages > id.sakuharian.desktop**.
4. Klik kanan `SakuHarianApp.java` dan pilih **Run File**, atau jalankan proyek dengan **Run Project**.
5. Jika diminta, tetapkan `id.sakuharian.desktop.SakuHarianApp` sebagai kelas utama proyek.

Aplikasi desktop memerlukan Java 17 atau lebih baru. Anggaran dan transaksi disimpan otomatis di folder `.saku-harian` dalam direktori home pengguna. Untuk membuat JAR, pilih **Clean and Build** di NetBeans; hasilnya berada di `desktop/target/saku-harian-1.0.0.jar`.

## Menjalankan aplikasi Android

1. Buka folder proyek ini di Android Studio.
2. Tunggu Gradle menyinkronkan proyek dan memasang Android SDK Platform 35 serta dependensi AndroidX Core bila diminta.
3. Pilih perangkat Android atau emulator, lalu tekan **Run**.

Untuk membuat APK debug, pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)** di Android Studio. APK tersedia di `app/build/outputs/apk/debug/app-debug.apk`.
