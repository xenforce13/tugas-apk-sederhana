package id.sakuharian.desktop;

import java.time.LocalDate;

public record Transaction(
        String id,
        String title,
        String category,
        long amount,
        LocalDate date,
        boolean income
) {
    public Transaction {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("ID transaksi wajib diisi.");
        }
        if (title == null || title.isBlank()) {
            throw new IllegalArgumentException("Nama transaksi wajib diisi.");
        }
        if (category == null || category.isBlank()) {
            throw new IllegalArgumentException("Kategori transaksi wajib diisi.");
        }
        if (amount <= 0) {
            throw new IllegalArgumentException("Jumlah transaksi harus lebih dari nol.");
        }
        if (date == null) {
            throw new IllegalArgumentException("Tanggal transaksi wajib diisi.");
        }
    }
}
