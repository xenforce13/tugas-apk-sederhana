package id.sakuharian.desktop;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Properties;

public final class FinanceStore {
    private static final String VERSION = "1";
    private final Path dataDirectory;
    private final Path dataFile;

    public FinanceStore() {
        this(Path.of(System.getProperty("user.home"), ".saku-harian"));
    }

    public FinanceStore(Path dataDirectory) {
        this.dataDirectory = Objects.requireNonNull(dataDirectory, "dataDirectory")
                .toAbsolutePath().normalize();
        this.dataFile = this.dataDirectory.resolve("finance.properties");
    }

    public Data load() throws IOException {
        if (!Files.exists(dataFile)) {
            return new Data(List.of(), 0);
        }

        Properties properties = new Properties();
        try (InputStream input = Files.newInputStream(dataFile)) {
            properties.load(input);
        }

        String version = properties.getProperty("version");
        if (!VERSION.equals(version)) {
            throw new IOException("Versi data keuangan tidak dikenali: " + version);
        }

        try {
            int count = Integer.parseInt(properties.getProperty("transaction.count", "0"));
            long budget = Long.parseLong(properties.getProperty("budget", "0"));
            if (count < 0 || budget < 0) {
                throw new NumberFormatException("Jumlah transaksi atau anggaran tidak valid.");
            }

            List<Transaction> transactions = new ArrayList<>(count);
            for (int index = 0; index < count; index++) {
                String prefix = "transaction." + index + ".";
                String income = require(properties, prefix + "income");
                if (!income.equals("true") && !income.equals("false")) {
                    throw new IllegalArgumentException("Jenis transaksi tidak valid.");
                }
                transactions.add(new Transaction(
                        require(properties, prefix + "id"),
                        require(properties, prefix + "title"),
                        require(properties, prefix + "category"),
                        Long.parseLong(require(properties, prefix + "amount")),
                        LocalDate.parse(require(properties, prefix + "date")),
                        Boolean.parseBoolean(income)
                ));
            }
            return new Data(List.copyOf(transactions), budget);
        } catch (IllegalArgumentException exception) {
            throw new IOException("Data transaksi atau anggaran rusak.", exception);
        }
    }

    public void save(List<Transaction> transactions, long budget) throws IOException {
        if (budget < 0) {
            throw new IllegalArgumentException("Anggaran tidak boleh negatif.");
        }

        Properties properties = new Properties();
        properties.setProperty("version", VERSION);
        properties.setProperty("budget", Long.toString(budget));
        properties.setProperty("transaction.count", Integer.toString(transactions.size()));
        for (int index = 0; index < transactions.size(); index++) {
            Transaction transaction = transactions.get(index);
            String prefix = "transaction." + index + ".";
            properties.setProperty(prefix + "id", transaction.id());
            properties.setProperty(prefix + "title", transaction.title());
            properties.setProperty(prefix + "category", transaction.category());
            properties.setProperty(prefix + "amount", Long.toString(transaction.amount()));
            properties.setProperty(prefix + "date", transaction.date().toString());
            properties.setProperty(prefix + "income", Boolean.toString(transaction.income()));
        }

        Files.createDirectories(dataDirectory);
        Path temporaryFile = Files.createTempFile(dataDirectory, "finance-", ".tmp");
        try {
            try (OutputStream output = Files.newOutputStream(temporaryFile)) {
                properties.store(output, "Saku Harian financial records");
            }
            try {
                Files.move(temporaryFile, dataFile,
                        StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(temporaryFile, dataFile, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temporaryFile);
        }
    }

    private String require(Properties properties, String key) {
        String value = properties.getProperty(key);
        if (value == null) {
            throw new IllegalArgumentException("Data transaksi tidak lengkap.");
        }
        return value;
    }

    public record Data(List<Transaction> transactions, long budget) {
    }
}
