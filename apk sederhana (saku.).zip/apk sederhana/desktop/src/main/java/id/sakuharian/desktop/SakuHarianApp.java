package id.sakuharian.desktop;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.stream.Collectors;

public final class SakuHarianApp extends JFrame {
    private static final long serialVersionUID = 1L;

    private static final Color BACKGROUND = new Color(246, 248, 244);
    private static final Color GREEN = new Color(24, 101, 73);
    private static final Color LIGHT_GREEN = new Color(225, 242, 230);
    private static final Color LIME = new Color(217, 240, 128);
    private static final Color TEXT = new Color(31, 42, 35);
    private static final Color MUTED = new Color(122, 137, 126);
    private static final Color RED = new Color(203, 83, 78);
    private static final Color LINE = new Color(236, 240, 234);
    private static final Locale INDONESIAN = Locale.forLanguageTag("id-ID");
    private static final DateTimeFormatter DATE_FORMAT =
            DateTimeFormatter.ofPattern("d MMM yyyy", INDONESIAN);
    private static final String[] CATEGORIES = {
            "Makanan", "Transportasi", "Belanja", "Tagihan", "Lainnya"
    };

    private final transient FinanceStore store;
    private final transient List<Transaction> transactions = new ArrayList<>();
    private final JComboBox<String> categoryFilter =
            new JComboBox<>(new String[]{"Semua kategori", "Makanan", "Transportasi",
                    "Belanja", "Tagihan", "Lainnya"});
    private final JPanel transactionList = new JPanel();
    private final JPanel summaryCards = new JPanel(new GridBagLayout());
    private final RoundedPanel heroCard = new RoundedPanel(GREEN, 22);
    private final WeeklyChart weeklyChart = new WeeklyChart();
    private final JLabel monthlyExpenses = new JLabel();
    private final JLabel budgetRemainder = new JLabel();
    private final JLabel budgetDescription = new JLabel();
    private final JProgressBar budgetProgress = new JProgressBar(0, 100);
    private long budget;

    public SakuHarianApp(FinanceStore store, FinanceStore.Data data) {
        super("Saku Harian");
        this.store = store;
        transactions.addAll(data.transactions());
        budget = data.budget();
        buildWindow();
        renderDashboard();
    }

    public static void main(String[] arguments) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                FinanceStore store = new FinanceStore();
                SakuHarianApp application = new SakuHarianApp(store, store.load());
                application.setVisible(true);
            } catch (IOException | ReflectiveOperationException
                     | javax.swing.UnsupportedLookAndFeelException exception) {
                JOptionPane.showMessageDialog(null,
                        "Aplikasi tidak dapat membaca data keuangan:\n" + exception.getMessage(),
                        "Gagal membuka Saku Harian", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void buildWindow() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(850, 700));
        setSize(1040, 900);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BACKGROUND);
        summaryCards.setPreferredSize(new Dimension(245, 146));
        summaryCards.setMinimumSize(new Dimension(205, 120));

        JPanel page = new JPanel(new BorderLayout(0, 20));
        page.setBackground(BACKGROUND);
        page.setBorder(new EmptyBorder(24, 34, 28, 34));
        page.add(buildNavigation(), BorderLayout.NORTH);

        JPanel dashboard = new JPanel();
        dashboard.setBackground(BACKGROUND);
        dashboard.setLayout(new BoxLayout(dashboard, BoxLayout.Y_AXIS));
        dashboard.add(buildOverview());
        dashboard.add(Box.createVerticalStrut(18));
        dashboard.add(buildBudgetCard());
        dashboard.add(Box.createVerticalStrut(18));
        dashboard.add(buildWeeklyCard());
        dashboard.add(Box.createVerticalStrut(18));
        dashboard.add(buildTransactionsCard());

        JScrollPane scrollPane = new JScrollPane(dashboard);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setViewportBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(BACKGROUND);
        scrollPane.setBackground(BACKGROUND);
        scrollPane.getVerticalScrollBar().setUnitIncrement(18);
        scrollPane.getVerticalScrollBar().setPreferredSize(new Dimension(8, 0));
        page.add(scrollPane, BorderLayout.CENTER);
        setContentPane(page);
    }

    private JPanel buildNavigation() {
        JPanel navigation = new JPanel(new BorderLayout());
        navigation.setOpaque(false);
        JPanel brand = new JPanel();
        brand.setOpaque(false);
        brand.setLayout(new BoxLayout(brand, BoxLayout.Y_AXIS));
        JLabel name = label("saku.", 30, GREEN, true);
        JLabel tagline = label("Keuangan lebih tenang, setiap hari.", 13, MUTED, false);
        brand.add(name);
        brand.add(Box.createVerticalStrut(3));
        brand.add(tagline);
        navigation.add(brand, BorderLayout.WEST);

        JButton export = button("Ekspor CSV", GREEN, Color.WHITE);
        export.addActionListener(event -> exportTransactions());
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 7));
        actions.setOpaque(false);
        actions.add(export);
        navigation.add(actions, BorderLayout.EAST);
        return navigation;
    }

    private JPanel buildOverview() {
        JPanel overview = new JPanel(new GridBagLayout());
        overview.setOpaque(false);
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridy = 0;
        constraints.gridx = 0;
        constraints.weightx = 0.7;
        constraints.weighty = 1;
        constraints.fill = GridBagConstraints.BOTH;
        overview.add(buildHeroCard(), constraints);
        constraints.gridx = 1;
        constraints.weightx = 0.3;
        constraints.insets = new Insets(0, 12, 0, 0);
        overview.add(summaryCards, constraints);
        return overview;
    }

    private JPanel buildHeroCard() {
        heroCard.setLayout(new BoxLayout(heroCard, BoxLayout.Y_AXIS));
        heroCard.setBorder(new EmptyBorder(20, 24, 20, 24));

        JPanel heading = transparentPanel(new BorderLayout());
        heading.add(label("PENGELUARAN BULAN INI", 12, new Color(205, 227, 211), true),
                BorderLayout.WEST);
        JPanel headerActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        headerActions.setOpaque(false);
        JLabel month = label(LocalDate.now().format(
                DateTimeFormatter.ofPattern("MMMM yyyy", INDONESIAN)), 12, Color.WHITE, true);
        headerActions.add(month);
        JButton setBudget = linkButton("Anggaran");
        setBudget.setForeground(LIME);
        setBudget.addActionListener(event -> showBudgetDialog());
        headerActions.add(setBudget);
        heading.add(headerActions, BorderLayout.EAST);
        heroCard.add(heading);

        monthlyExpenses.setFont(new Font("SansSerif", Font.BOLD, 32));
        monthlyExpenses.setForeground(Color.WHITE);
        monthlyExpenses.setBorder(new EmptyBorder(15, 0, 1, 0));
        heroCard.add(monthlyExpenses);

        JLabel hint = label("Setiap catatan kecil membantu kamu lebih sadar.", 12,
                new Color(205, 227, 211), false);
        heroCard.add(hint);

        JPanel footer = transparentPanel(new BorderLayout());
        footer.setBorder(new EmptyBorder(19, 0, 0, 0));
        footer.add(label("Sisa anggaran", 12, new Color(205, 227, 211), false),
                BorderLayout.WEST);
        budgetRemainder.setFont(new Font("SansSerif", Font.BOLD, 15));
        budgetRemainder.setForeground(LIME);
        footer.add(budgetRemainder, BorderLayout.EAST);
        heroCard.add(Box.createVerticalGlue());
        heroCard.add(footer);
        return heroCard;
    }

    private JPanel buildBudgetCard() {
        JPanel card = cardPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        JPanel heading = transparentPanel(new BorderLayout());
        heading.add(label("Anggaran bulanan", 15, TEXT, true), BorderLayout.WEST);
        JButton edit = linkButton("Atur anggaran");
        edit.addActionListener(event -> showBudgetDialog());
        heading.add(edit, BorderLayout.EAST);
        card.add(heading);

        budgetDescription.setFont(new Font("SansSerif", Font.PLAIN, 12));
        budgetDescription.setForeground(MUTED);
        budgetDescription.setBorder(new EmptyBorder(12, 0, 9, 0));
        card.add(budgetDescription);

        budgetProgress.setStringPainted(false);
        budgetProgress.setBorderPainted(false);
        budgetProgress.setOpaque(false);
        budgetProgress.setPreferredSize(new Dimension(0, 8));
        budgetProgress.setMaximumSize(new Dimension(Integer.MAX_VALUE, 8));
        card.add(budgetProgress);
        return card;
    }

    private JPanel buildWeeklyCard() {
        JPanel card = cardPanel();
        card.setLayout(new BorderLayout(0, 12));
        JPanel heading = transparentPanel(new BorderLayout());
        heading.add(label("Pengeluaran mingguan", 15, TEXT, true), BorderLayout.WEST);
        heading.add(label("7 hari terakhir", 12, MUTED, false), BorderLayout.EAST);
        card.add(heading, BorderLayout.NORTH);
        weeklyChart.setPreferredSize(new Dimension(0, 145));
        weeklyChart.setOpaque(false);
        card.add(weeklyChart, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildTransactionsCard() {
        JPanel card = cardPanel();
        card.setLayout(new BorderLayout(0, 12));

        JPanel heading = transparentPanel(new BorderLayout(12, 0));
        heading.add(label("Transaksi", 18, TEXT, true), BorderLayout.WEST);
        JPanel filters = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        filters.setOpaque(false);
        categoryFilter.setFont(new Font("SansSerif", Font.PLAIN, 12));
        categoryFilter.setForeground(TEXT);
        categoryFilter.setBackground(Color.WHITE);
        categoryFilter.addActionListener(event -> renderTransactions());
        filters.add(categoryFilter);
        JButton export = linkButton("Ekspor CSV");
        export.addActionListener(event -> exportTransactions());
        filters.add(export);
        heading.add(filters, BorderLayout.EAST);
        card.add(heading, BorderLayout.NORTH);

        transactionList.setOpaque(false);
        transactionList.setLayout(new BoxLayout(transactionList, BoxLayout.Y_AXIS));
        card.add(transactionList, BorderLayout.CENTER);

        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);
        footer.add(label(transactions.size() + " catatan tersimpan", 11, MUTED, false),
                BorderLayout.WEST);
        JButton add = button("+  Tambah transaksi", GREEN, Color.WHITE);
        add.addActionListener(event -> showTransactionDialog(null));
        footer.add(add, BorderLayout.EAST);
        card.add(footer, BorderLayout.SOUTH);
        return card;
    }

    private void renderDashboard() {
        summaryCards.removeAll();
        summaryCards.setLayout(new GridBagLayout());
        addSummaryCard("Pemasukan bulan ini", monthlyTotal(true),
                new Color(220, 241, 227), GREEN, 0);
        addSummaryCard("Pengeluaran bulan ini", monthlyTotal(false),
                new Color(250, 232, 229), RED, 1);

        long spending = monthlyTotal(false);
        monthlyExpenses.setText(formatCurrency(spending));
        budgetRemainder.setText(budget > 0
                ? formatCurrency(budget - spending) : "Atur sekarang  →");
        budgetDescription.setText(budget > 0
                ? formatCurrency(spending) + " dari " + formatCurrency(budget)
                : "Tetapkan batas agar pengeluaran tetap terkontrol.");
        budgetProgress.setValue(budget == 0 ? 0
                : (int) Math.min(100, (spending * 100.0) / budget));
        budgetProgress.setForeground(spending > budget && budget > 0 ? RED : GREEN);
        weeklyChart.repaint();
        renderTransactions();
        summaryCards.revalidate();
        summaryCards.repaint();
        revalidate();
        repaint();
    }

    private void addSummaryCard(String title, long amount, Color background,
                                Color accent, int index) {
        JPanel summary = new RoundedPanel(background, 18);
        summary.setLayout(new BoxLayout(summary, BoxLayout.Y_AXIS));
        summary.setBorder(new EmptyBorder(12, 13, 12, 13));
        summary.add(label(title, 12, MUTED, false));
        JLabel value = label(formatCompactCurrency(amount), 17, accent, true);
        value.setBorder(new EmptyBorder(8, 0, 0, 0));
        summary.add(value);
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = index;
        constraints.weightx = 0;
        constraints.weighty = 0.5;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = index == 0
                ? new Insets(0, 0, 8, 0) : new Insets(8, 0, 0, 0);
        summaryCards.add(summary, constraints);
    }

    private void renderTransactions() {
        transactionList.removeAll();
        String selectedCategory = (String) categoryFilter.getSelectedItem();
        List<Transaction> visible = transactions.stream()
                .filter(transaction -> "Semua kategori".equals(selectedCategory)
                        || transaction.category().equals(selectedCategory))
                .sorted(Comparator.comparing(Transaction::date).reversed())
                .collect(Collectors.toList());

        if (visible.isEmpty()) {
            JLabel empty = label(transactions.isEmpty()
                            ? "Belum ada catatan. Tambahkan transaksi pertamamu."
                            : "Tidak ada transaksi pada kategori ini.",
                    13, MUTED, false);
            empty.setBorder(new EmptyBorder(24, 4, 24, 4));
            transactionList.add(empty);
        } else {
            for (Transaction transaction : visible) {
                transactionList.add(buildTransactionRow(transaction));
                transactionList.add(Box.createVerticalStrut(8));
            }
        }
        transactionList.revalidate();
        transactionList.repaint();
    }

    private JPanel buildTransactionRow(Transaction transaction) {
        JPanel row = new JPanel(new BorderLayout(13, 0));
        row.setOpaque(false);
        row.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, LINE));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 66));
        JLabel category = new JLabel(categoryIcon(transaction.category()), SwingConstants.CENTER);
        category.setFont(new Font("SansSerif", Font.BOLD, 17));
        category.setForeground(GREEN);
        category.setOpaque(true);
        category.setBackground(LIGHT_GREEN);
        category.setPreferredSize(new Dimension(42, 42));
        row.add(category, BorderLayout.WEST);

        JPanel details = new JPanel();
        details.setOpaque(false);
        details.setLayout(new BoxLayout(details, BoxLayout.Y_AXIS));
        details.add(label(transaction.title(), 13, TEXT, true));
        details.add(Box.createVerticalStrut(4));
        details.add(label(transaction.category() + "  ·  " + DATE_FORMAT.format(transaction.date()),
                11, MUTED, false));
        row.add(details, BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 9));
        actions.setOpaque(false);
        JLabel amount = label((transaction.income() ? "+ " : "− ")
                + formatCompactCurrency(transaction.amount()),
                13, transaction.income() ? GREEN : TEXT, true);
        actions.add(amount);
        JButton edit = linkButton("Ubah");
        edit.addActionListener(event -> showTransactionDialog(transaction));
        actions.add(edit);
        JButton delete = linkButton("Hapus");
        delete.setForeground(RED);
        delete.addActionListener(event -> deleteTransaction(transaction));
        actions.add(delete);
        row.add(actions, BorderLayout.EAST);
        return row;
    }

    private void showTransactionDialog(Transaction existing) {
        JDialog dialog = new JDialog((Frame) this,
                existing == null ? "Tambah transaksi" : "Ubah transaksi",
                JDialog.ModalityType.APPLICATION_MODAL);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(new EmptyBorder(22, 24, 16, 24));

        JComboBox<String> type = new JComboBox<>(new String[]{"Pengeluaran", "Pemasukan"});
        type.setSelectedItem(existing != null && existing.income() ? "Pemasukan" : "Pengeluaran");
        JTextField title = new JTextField(existing == null ? "" : existing.title(), 22);
        JTextField amount = new JTextField(existing == null
                ? "" : Long.toString(existing.amount()), 22);
        JComboBox<String> category = new JComboBox<>(CATEGORIES);
        if (existing != null) {
            category.setSelectedItem(existing.category());
        }
        JSpinner date = new JSpinner(new SpinnerDateModel(
                Date.from((existing == null ? LocalDate.now() : existing.date())
                        .atStartOfDay(ZoneId.systemDefault()).toInstant()),
                null, null, java.util.Calendar.DAY_OF_MONTH));
        date.setEditor(new JSpinner.DateEditor(date, "d MMMM yyyy"));

        addFormRow(form, "Jenis transaksi", type, 0);
        addFormRow(form, "Nama transaksi", title, 1);
        addFormRow(form, "Jumlah (Rp)", amount, 2);
        addFormRow(form, "Kategori", category, 3);
        addFormRow(form, "Tanggal", date, 4);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        actions.setOpaque(false);
        JButton cancel = button("Batal", new Color(241, 244, 239), TEXT);
        cancel.addActionListener(event -> dialog.dispose());
        JButton save = button(existing == null ? "Simpan transaksi" : "Simpan perubahan",
                GREEN, Color.WHITE);
        save.addActionListener(event -> {
            long parsedAmount;
            String rawAmount = amount.getText().trim().replaceAll("[.\\s]", "");
            try {
                parsedAmount = Long.parseLong(rawAmount);
                if (parsedAmount <= 0) {
                    throw new NumberFormatException();
                }
            } catch (NumberFormatException exception) {
                showError(dialog, "Masukkan jumlah yang valid dan lebih besar dari nol.");
                return;
            }
            if (title.getText().isBlank()) {
                showError(dialog, "Nama transaksi tidak boleh kosong.");
                return;
            }

            LocalDate selectedDate = ((Date) date.getValue()).toInstant()
                    .atZone(ZoneId.systemDefault()).toLocalDate();
            Transaction updated = new Transaction(
                    existing == null ? UUID.randomUUID().toString() : existing.id(),
                    title.getText().trim(), (String) category.getSelectedItem(), parsedAmount,
                    selectedDate, "Pemasukan".equals(type.getSelectedItem()));
            List<Transaction> previous = new ArrayList<>(transactions);
            transactions.removeIf(transaction -> existing != null
                    && transaction.id().equals(existing.id()));
            transactions.add(updated);
            if (!persist()) {
                transactions.clear();
                transactions.addAll(previous);
                return;
            }
            dialog.dispose();
            renderDashboard();
            if (!updated.income() && budget > 0 && monthlyTotal(false) > budget) {
                JOptionPane.showMessageDialog(this,
                        "Pengeluaran bulan ini sudah melewati anggaran.",
                        "Anggaran terlampaui", JOptionPane.WARNING_MESSAGE);
            }
        });
        actions.add(cancel);
        actions.add(save);

        dialog.add(form, BorderLayout.CENTER);
        dialog.add(actions, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setMinimumSize(new Dimension(430, dialog.getPreferredSize().height));
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void showBudgetDialog() {
        JTextField input = new JTextField(budget > 0 ? Long.toString(budget) : "", 18);
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(new EmptyBorder(12, 12, 4, 12));
        addFormRow(form, "Batas pengeluaran per bulan (Rp)", input, 0);
        while (true) {
            int result = JOptionPane.showConfirmDialog(this, form,
                    "Atur anggaran bulanan", JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE);
            if (result != JOptionPane.OK_OPTION) {
                return;
            }
            String raw = input.getText().trim().replace(".", "").replace(",", "");
            try {
                long newBudget = Long.parseLong(raw);
                if (newBudget <= 0) {
                    throw new NumberFormatException();
                }
                long previous = budget;
                budget = newBudget;
                if (persist()) {
                    renderDashboard();
                } else {
                    budget = previous;
                }
                return;
            } catch (NumberFormatException exception) {
                showError(this, "Masukkan anggaran yang valid dan lebih besar dari nol.");
            }
        }
    }

    private void deleteTransaction(Transaction transaction) {
        int result = JOptionPane.showConfirmDialog(this,
                "Hapus catatan \"" + transaction.title() + "\"?",
                "Hapus transaksi", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (result != JOptionPane.YES_OPTION) {
            return;
        }
        transactions.remove(transaction);
        if (!persist()) {
            transactions.add(transaction);
            return;
        }
        renderDashboard();
    }

    private void exportTransactions() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Ekspor catatan transaksi");
        chooser.setFileFilter(new FileNameExtensionFilter("File CSV (*.csv)", "csv"));
        chooser.setSelectedFile(new java.io.File("catatan-keuangan.csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }

        java.io.File selectedFile = chooser.getSelectedFile();
        java.io.File csvFile = selectedFile.getName().toLowerCase(Locale.ROOT).endsWith(".csv")
                ? selectedFile : new java.io.File(selectedFile.getParentFile(),
                selectedFile.getName() + ".csv");
        if (csvFile.exists() && JOptionPane.showConfirmDialog(this,
                "File \"" + csvFile.getName() + "\" sudah ada. Timpa file ini?",
                "Konfirmasi", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE)
                != JOptionPane.YES_OPTION) {
            return;
        }
        StringBuilder csv = new StringBuilder("\uFEFFTanggal,Nama,Kategori,Jenis,Jumlah (Rp)\n");
        transactions.stream().sorted(Comparator.comparing(Transaction::date))
                .forEach(transaction -> csv.append(csvField(DATE_FORMAT.format(transaction.date())))
                        .append(',').append(csvField(transaction.title()))
                        .append(',').append(csvField(transaction.category()))
                        .append(',').append(transaction.income() ? "Pemasukan" : "Pengeluaran")
                        .append(',').append(transaction.amount()).append('\n'));
        try {
            Files.writeString(csvFile.toPath(), csv.toString(), StandardCharsets.UTF_8);
            JOptionPane.showMessageDialog(this, "Catatan berhasil diekspor ke:\n"
                            + csvFile.getAbsolutePath(),
                    "Ekspor berhasil", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException exception) {
            showError(this, "File CSV tidak dapat disimpan:\n" + exception.getMessage());
        }
    }

    private boolean persist() {
        try {
            store.save(List.copyOf(transactions), budget);
            return true;
        } catch (IOException exception) {
            showError(this, "Data tidak dapat disimpan:\n" + exception.getMessage());
            return false;
        }
    }

    private long monthlyTotal(boolean income) {
        LocalDate firstDay = LocalDate.now().withDayOfMonth(1);
        LocalDate nextMonth = firstDay.plusMonths(1);
        return transactions.stream()
                .filter(transaction -> transaction.income() == income)
                .filter(transaction -> !transaction.date().isBefore(firstDay)
                        && transaction.date().isBefore(nextMonth))
                .mapToLong(Transaction::amount)
                .sum();
    }

    private long[] weeklyTotals() {
        long[] totals = new long[7];
        LocalDate today = LocalDate.now();
        for (Transaction transaction : transactions) {
            if (transaction.income()) {
                continue;
            }
            long daysAgo = java.time.temporal.ChronoUnit.DAYS.between(transaction.date(), today);
            if (daysAgo >= 0 && daysAgo < totals.length) {
                totals[totals.length - 1 - (int) daysAgo] += transaction.amount();
            }
        }
        return totals;
    }

    private void addFormRow(JPanel form, String caption, Component field, int row) {
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = row;
        constraints.weightx = 0;
        constraints.anchor = GridBagConstraints.LINE_START;
        constraints.insets = new Insets(7, 4, 7, 12);
        JLabel label = label(caption, 12, TEXT, true);
        form.add(label, constraints);

        constraints.gridx = 1;
        constraints.weightx = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(7, 4, 7, 4);
        form.add(field, constraints);
    }

    private void showError(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message,
                "Tidak dapat melanjutkan", JOptionPane.ERROR_MESSAGE);
    }

    private static String formatCurrency(long amount) {
        return java.text.NumberFormat.getCurrencyInstance(INDONESIAN)
                .format(amount).replace(",00", "");
    }

    private static String formatCompactCurrency(long amount) {
        if (amount >= 1_000_000) {
            return "Rp" + compactNumber(amount / 1_000_000.0) + " jt";
        }
        if (amount >= 10_000) {
            return "Rp" + compactNumber(amount / 1_000.0) + " rb";
        }
        return "Rp" + java.text.NumberFormat.getIntegerInstance(INDONESIAN).format(amount);
    }

    private static String compactNumber(double value) {
        java.text.NumberFormat formatter = java.text.NumberFormat.getNumberInstance(INDONESIAN);
        formatter.setMaximumFractionDigits(value < 10 ? 1 : 0);
        return formatter.format(value);
    }

    private static String csvField(String value) {
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }

    private static String categoryIcon(String category) {
        return switch (category) {
            case "Makanan" -> "M";
            case "Transportasi" -> "T";
            case "Belanja" -> "B";
            case "Tagihan" -> "R";
            default -> "L";
        };
    }

    private static JLabel label(String text, int size, Color color, boolean bold) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("SansSerif", bold ? Font.BOLD : Font.PLAIN, size));
        label.setForeground(color);
        return label;
    }

    private static JPanel transparentPanel(BorderLayout layout) {
        JPanel panel = new JPanel(layout);
        panel.setOpaque(false);
        return panel;
    }

    private static JPanel cardPanel() {
        RoundedPanel panel = new RoundedPanel(Color.WHITE, 20);
        panel.setBorder(new EmptyBorder(17, 19, 17, 19));
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        return panel;
    }

    private static JButton button(String text, Color background, Color foreground) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 12));
        button.setForeground(foreground);
        button.setBackground(background);
        button.setFocusPainted(false);
        button.setBorder(new EmptyBorder(10, 16, 10, 16));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return button;
    }

    private static JButton linkButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 11));
        button.setForeground(GREEN);
        button.setContentAreaFilled(false);
        button.setBorder(new EmptyBorder(5, 6, 5, 6));
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return button;
    }

    private final class WeeklyChart extends JPanel {
        private static final long serialVersionUID = 1L;

        @Override
        protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            Graphics2D canvas = (Graphics2D) graphics.create();
            canvas.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);

            long[] daily = weeklyTotals();
            long maximum = 1;
            for (long amount : daily) {
                maximum = Math.max(maximum, amount);
            }
            int plotHeight = Math.max(24, getHeight() - 35);
            int step = getWidth() / daily.length;
            LocalDate today = LocalDate.now();
            for (int index = 0; index < daily.length; index++) {
                int barHeight = Math.max(7,
                        (int) (plotHeight * (daily[index] / (double) maximum)));
                int x = index * step + (step - 24) / 2;
                int y = plotHeight - barHeight;
                canvas.setColor(index == daily.length - 1 ? LIME : LIGHT_GREEN);
                canvas.fill(new RoundRectangle2D.Float(x, y, 24, barHeight, 12, 12));
                LocalDate day = today.plusDays(index - daily.length + 1L);
                String dayName = day.getDayOfWeek()
                        .getDisplayName(TextStyle.SHORT, INDONESIAN);
                canvas.setColor(MUTED);
                canvas.setFont(new Font("SansSerif", Font.PLAIN, 11));
                int labelWidth = canvas.getFontMetrics().stringWidth(dayName);
                canvas.drawString(dayName, index * step + (step - labelWidth) / 2,
                        plotHeight + 19);
            }
            canvas.setColor(LINE);
            canvas.setStroke(new BasicStroke(1));
            canvas.drawLine(0, plotHeight, getWidth(), plotHeight);
            canvas.dispose();
        }
    }

    private static final class RoundedPanel extends JPanel {
        private static final long serialVersionUID = 1L;

        private final Color color;
        private final int radius;

        private RoundedPanel(Color color, int radius) {
            this.color = color;
            this.radius = radius;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            Graphics2D canvas = (Graphics2D) graphics.create();
            canvas.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            canvas.setColor(color);
            canvas.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            canvas.dispose();
            super.paintComponent(graphics);
        }
    }
}
