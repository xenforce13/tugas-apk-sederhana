package id.sakuharian;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import org.json.JSONException;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int INK = Color.rgb(23, 32, 27);
    private static final int MUTED = Color.rgb(130, 144, 135);
    private static final int CANVAS = Color.rgb(245, 247, 243);
    private static final int GREEN = Color.rgb(23, 107, 77);
    private static final int MINT = Color.rgb(219, 243, 230);
    private static final int LIME = Color.rgb(213, 241, 106);
    private static final int RED = Color.rgb(214, 91, 87);
    private static final int WHITE = Color.WHITE;

    private final List<Transaction> transactions = new ArrayList<>();
    private FinanceStorage storage;
    private ScrollView scrollView;
    private LinearLayout content;
    private long budget;
    private String selectedFilter = "Semua";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat windowController =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        windowController.setAppearanceLightStatusBars(true);
        windowController.setAppearanceLightNavigationBars(true);
        storage = new FinanceStorage(this);
        budget = storage.loadBudget();
        try {
            transactions.addAll(storage.loadTransactions());
        } catch (JSONException exception) {
            Toast.makeText(this, "Data transaksi tidak dapat dibaca.", Toast.LENGTH_LONG).show();
        }
        buildScreen();
    }

    private void buildScreen() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(CANVAS);

        scrollView = new ScrollView(this);
        scrollView.setClipToPadding(false);
        scrollView.setFillViewport(true);
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            androidx.core.graphics.Insets systemBars =
                    insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(0, systemBars.top, 0, systemBars.bottom);
            return insets;
        });
        FrameLayout.LayoutParams scrollParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        scrollParams.bottomMargin = dp(82);
        root.addView(scrollView, scrollParams);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(13), dp(22), dp(32));
        scrollView.addView(content);

        TextView addButton = text("+", 29, GREEN, true);
        addButton.setGravity(Gravity.CENTER);
        addButton.setBackground(circle(LIME));
        addButton.setElevation(dp(7));
        FrameLayout.LayoutParams buttonParams = new FrameLayout.LayoutParams(dp(58), dp(58),
                Gravity.BOTTOM | Gravity.END);
        buttonParams.setMargins(0, 0, dp(23), dp(20));
        root.addView(addButton, buttonParams);
        addButton.setOnClickListener(view -> showTransactionDialog(null));

        setContentView(root);
        renderDashboard();
    }

    private void renderDashboard() {
        content.removeAllViews();
        addTopBar();
        addHeroCard();
        addSummaryCards();
        addBudgetCard();
        addChartCard();
        addTransactionSection();
    }

    private void addTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("saku.", 27, INK, true);
        bar.addView(brand, new LinearLayout.LayoutParams(0, dp(48), 1));

        TextView export = text("↗  Ekspor", 13, GREEN, true);
        export.setGravity(Gravity.CENTER);
        export.setPadding(dp(15), 0, dp(15), 0);
        export.setBackground(pill(MINT));
        bar.addView(export, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(37)));
        export.setOnClickListener(view -> exportTransactions());
        content.addView(bar);

        TextView subtitle = text("Keuangan lebih tenang, setiap hari.", 13, MUTED, false);
        LinearLayout.LayoutParams subtitleParams = params(-2, -2);
        subtitleParams.topMargin = dp(2);
        subtitleParams.bottomMargin = dp(20);
        content.addView(subtitle, subtitleParams);
    }

    private void addHeroCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(21), dp(19), dp(21), dp(20));
        card.setBackground(rounded(GREEN, 24));

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView caption = text("PENGELUARAN BULAN INI", 11, Color.rgb(199, 226, 210), true);
        heading.addView(caption, new LinearLayout.LayoutParams(0, -2, 1));
        Calendar now = Calendar.getInstance();
        String month = new SimpleDateFormat("MMM yyyy", new Locale("id", "ID"))
                .format(now.getTime());
        TextView monthLabel = text(month, 11, WHITE, true);
        monthLabel.setPadding(dp(10), dp(6), dp(10), dp(6));
        monthLabel.setBackground(pill(Color.rgb(44, 126, 91)));
        heading.addView(monthLabel);
        card.addView(heading);

        TextView total = text(formatCurrency(monthlyExpenses()), 32, WHITE, true);
        LinearLayout.LayoutParams totalParams = params(-2, -2);
        totalParams.topMargin = dp(11);
        card.addView(total, totalParams);

        TextView hint = text("Catat sedikit demi sedikit, hasilnya terasa.", 12,
                Color.rgb(199, 226, 210), false);
        LinearLayout.LayoutParams hintParams = params(-2, -2);
        hintParams.topMargin = dp(5);
        card.addView(hint, hintParams);

        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(56, 130, 97));
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(-1, dp(1));
        dividerParams.setMargins(0, dp(17), 0, dp(12));
        card.addView(divider, dividerParams);

        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        TextView balanceCaption = text("Sisa anggaran", 12, Color.rgb(199, 226, 210), false);
        footer.addView(balanceCaption, new LinearLayout.LayoutParams(0, -2, 1));
        long remaining = budget > 0 ? budget - monthlyExpenses() : 0;
        TextView balance = text(budget > 0 ? formatCurrency(remaining) : "Atur anggaran  →",
                13, LIME, true);
        footer.addView(balance);
        footer.setOnClickListener(view -> showBudgetDialog());
        card.addView(footer);

        content.addView(card, params(-1, -2));
        card.setOnClickListener(view -> showBudgetDialog());
    }

    private void addSummaryCards() {
        LinearLayout row = new LinearLayout(this);
        LinearLayout.LayoutParams rowParams = params(-1, -2);
        rowParams.topMargin = dp(15);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(summaryCard("↙", "Pemasukan", monthlyIncome(), GREEN),
                new LinearLayout.LayoutParams(0, dp(100), 1));
        View spacer = new View(this);
        row.addView(spacer, new LinearLayout.LayoutParams(dp(11), 1));
        row.addView(summaryCard("↗", "Pengeluaran", monthlyExpenses(), RED),
                new LinearLayout.LayoutParams(0, dp(100), 1));
        content.addView(row, rowParams);
    }

    private View summaryCard(String symbol, String label, long amount, int accent) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(13), dp(12), dp(11), dp(11));
        card.setBackground(rounded(WHITE, 18));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = text(symbol, 16, accent, true);
        TextView title = text("  " + label, 11, MUTED, false);
        header.addView(icon);
        header.addView(title);
        card.addView(header);

        TextView value = text(formatCompactCurrency(amount), 15, INK, true);
        LinearLayout.LayoutParams valueParams = params(-2, -2);
        valueParams.topMargin = dp(9);
        card.addView(value, valueParams);
        return card;
    }

    private void addBudgetCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(rounded(WHITE, 18));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Anggaran bulanan", 13, INK, true);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView edit = text(budget > 0 ? "Ubah  ↗" : "+ Atur", 12, GREEN, true);
        titleRow.addView(edit);
        titleRow.setOnClickListener(view -> showBudgetDialog());
        card.addView(titleRow);

        if (budget > 0) {
            long spent = monthlyExpenses();
            int percent = (int) Math.min(100, (spent * 100.0) / budget);
            TextView description = text(formatCurrency(spent) + " dari " + formatCurrency(budget),
                    11, MUTED, false);
            LinearLayout.LayoutParams descParams = params(-2, -2);
            descParams.topMargin = dp(7);
            card.addView(description, descParams);

            FrameLayout track = new FrameLayout(this);
            track.setBackground(rounded(Color.rgb(235, 239, 234), 9));
            LinearLayout.LayoutParams trackParams = new LinearLayout.LayoutParams(-1, dp(7));
            trackParams.topMargin = dp(10);
            card.addView(track, trackParams);
            View fill = new View(this);
            fill.setBackground(rounded(spent > budget ? RED : GREEN, 9));
            FrameLayout.LayoutParams fillParams = new FrameLayout.LayoutParams(
                    Math.max(dp(7), (int) ((getResources().getDisplayMetrics().widthPixels
                            - dp(76)) * (percent / 100f))), -1, Gravity.START);
            track.addView(fill, fillParams);
        } else {
            TextView description = text("Pasang batas agar pengeluaran tetap terkendali.",
                    11, MUTED, false);
            LinearLayout.LayoutParams descParams = params(-2, -2);
            descParams.topMargin = dp(5);
            card.addView(description, descParams);
        }

        LinearLayout.LayoutParams cardParams = params(-1, -2);
        cardParams.topMargin = dp(13);
        content.addView(card, cardParams);
        card.setOnClickListener(view -> showBudgetDialog());
    }

    private void addChartCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(12));
        card.setBackground(rounded(WHITE, 18));

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.addView(text("Ringkasan pengeluaran", 13, INK, true),
                new LinearLayout.LayoutParams(0, -2, 1));
        heading.addView(text("7 hari terakhir", 10, MUTED, false));
        card.addView(heading);

        LinearLayout chart = new LinearLayout(this);
        chart.setGravity(Gravity.BOTTOM);
        chart.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams chartParams = new LinearLayout.LayoutParams(-1, dp(93));
        chartParams.topMargin = dp(12);
        long[] daily = lastSevenDaysExpenses();
        long max = 1;
        for (long amount : daily) {
            max = Math.max(max, amount);
        }
        Calendar today = Calendar.getInstance();
        for (int index = 0; index < daily.length; index++) {
            LinearLayout column = new LinearLayout(this);
            column.setOrientation(LinearLayout.VERTICAL);
            column.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            column.setPadding(dp(5), 0, dp(5), 0);
            LinearLayout.LayoutParams columnParams = new LinearLayout.LayoutParams(0, -1, 1);

            View bar = new View(this);
            int barHeight = Math.max(dp(7), (int) (dp(54) * (daily[index] / (float) max)));
            bar.setBackground(rounded(index == 6 ? LIME : MINT, 8));
            column.addView(bar, new LinearLayout.LayoutParams(dp(16), barHeight));
            Calendar day = (Calendar) today.clone();
            day.add(Calendar.DAY_OF_YEAR, index - 6);
            TextView dayLabel = text(new SimpleDateFormat("EE", new Locale("id", "ID"))
                    .format(day.getTime()), 9, MUTED, false);
            dayLabel.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(-1, dp(21));
            column.addView(dayLabel, labelParams);
            chart.addView(column, columnParams);
        }
        card.addView(chart, chartParams);

        LinearLayout.LayoutParams cardParams = params(-1, -2);
        cardParams.topMargin = dp(13);
        content.addView(card, cardParams);
    }

    private void addTransactionSection() {
        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Transaksi", 18, INK, true);
        heading.addView(title, new LinearLayout.LayoutParams(0, dp(46), 1));
        TextView count = text(transactions.size() + " catatan", 11, MUTED, false);
        heading.addView(count);
        LinearLayout.LayoutParams headingParams = params(-1, -2);
        headingParams.topMargin = dp(11);
        content.addView(heading, headingParams);

        HorizontalScrollView filters = new HorizontalScrollView(this);
        filters.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        String[] categories = {"Semua", "Makanan", "Transportasi", "Belanja", "Tagihan", "Lainnya"};
        for (String category : categories) {
            TextView chip = text(category, 11, selectedFilter.equals(category) ? WHITE : MUTED, true);
            chip.setPadding(dp(13), dp(8), dp(13), dp(8));
            chip.setBackground(pill(selectedFilter.equals(category) ? GREEN : WHITE));
            LinearLayout.LayoutParams chipParams = new LinearLayout.LayoutParams(-2, -2);
            chipParams.rightMargin = dp(7);
            chips.addView(chip, chipParams);
            chip.setOnClickListener(view -> {
                int scrollPosition = scrollView.getScrollY();
                selectedFilter = category;
                renderDashboard();
                scrollView.post(() -> scrollView.scrollTo(0, scrollPosition));
            });
        }
        filters.addView(chips);
        content.addView(filters);

        List<Transaction> visible = new ArrayList<>();
        for (Transaction transaction : transactions) {
            if (selectedFilter.equals("Semua")
                    || transaction.category.equals(selectedFilter)) {
                visible.add(transaction);
            }
        }
        Collections.sort(visible, (first, second) -> Long.compare(second.dateMillis, first.dateMillis));

        if (visible.isEmpty()) {
            TextView empty = text("Belum ada transaksi.\nTekan + untuk mulai mencatat.",
                    12, MUTED, false);
            empty.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams emptyParams = new LinearLayout.LayoutParams(-1, dp(105));
            emptyParams.topMargin = dp(9);
            empty.setBackground(rounded(WHITE, 18));
            content.addView(empty, emptyParams);
            return;
        }

        for (Transaction transaction : visible) {
            content.addView(transactionRow(transaction));
        }
    }

    private View transactionRow(Transaction transaction) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(11), dp(12), dp(11));
        row.setBackground(rounded(WHITE, 17));

        TextView icon = text(categoryIcon(transaction.category), 18, GREEN, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(circle(MINT));
        row.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));

        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);
        details.setPadding(dp(10), 0, 0, 0);
        details.addView(text(transaction.title, 12, INK, true));
        TextView subtext = text(transaction.category + "  ·  " + transaction.formattedDate(),
                10, MUTED, false);
        LinearLayout.LayoutParams subParams = params(-2, -2);
        subParams.topMargin = dp(4);
        details.addView(subtext, subParams);
        row.addView(details, new LinearLayout.LayoutParams(0, -2, 1));

        int amountColor = transaction.income ? GREEN : INK;
        String prefix = transaction.income ? "+ " : "− ";
        TextView amount = text(prefix + formatCompactCurrency(transaction.amount), 12,
                amountColor, true);
        row.addView(amount);

        LinearLayout.LayoutParams rowParams = params(-1, -2);
        rowParams.topMargin = dp(8);
        row.setOnLongClickListener(view -> {
            new AlertDialog.Builder(this)
                    .setTitle("Hapus transaksi?")
                    .setMessage("Catatan \"" + transaction.title + "\" akan dihapus.")
                    .setNegativeButton("Batal", null)
                    .setPositiveButton("Hapus", (dialog, which) -> deleteTransaction(transaction))
                    .show();
            return true;
        });
        row.setOnClickListener(view -> showTransactionDialog(transaction));
        row.setLayoutParams(rowParams);
        return row;
    }

    private void showTransactionDialog(Transaction existing) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(22), dp(8), dp(22), dp(6));

        final boolean[] income = {existing != null && existing.income};
        LinearLayout typeRow = new LinearLayout(this);
        Button expenseButton = typeButton("Pengeluaran", !income[0]);
        Button incomeButton = typeButton("Pemasukan", income[0]);
        typeRow.addView(expenseButton, new LinearLayout.LayoutParams(0, dp(42), 1));
        View gap = new View(this);
        typeRow.addView(gap, new LinearLayout.LayoutParams(dp(8), 1));
        typeRow.addView(incomeButton, new LinearLayout.LayoutParams(0, dp(42), 1));
        form.addView(typeRow);
        expenseButton.setOnClickListener(view -> {
            income[0] = false;
            styleTypeButton(expenseButton, true);
            styleTypeButton(incomeButton, false);
        });
        incomeButton.setOnClickListener(view -> {
            income[0] = true;
            styleTypeButton(expenseButton, false);
            styleTypeButton(incomeButton, true);
        });

        EditText titleInput = input("Nama transaksi", InputType.TYPE_CLASS_TEXT);
        if (existing != null) {
            titleInput.setText(existing.title);
        }
        addFormField(form, "Nama", titleInput);

        EditText amountInput = input("Contoh: 25000",
                InputType.TYPE_CLASS_NUMBER);
        if (existing != null) {
            amountInput.setText(String.valueOf(existing.amount));
        }
        addFormField(form, "Jumlah (Rp)", amountInput);

        String[] categories = {"Makanan", "Transportasi", "Belanja", "Tagihan", "Lainnya"};
        final String[] selectedCategory = {
                existing == null ? categories[0] : existing.category
        };
        TextView categoryPicker = text("Kategori  ·  " + selectedCategory[0] + "  ▾",
                13, INK, false);
        categoryPicker.setGravity(Gravity.CENTER_VERTICAL);
        categoryPicker.setPadding(dp(13), 0, dp(13), 0);
        categoryPicker.setBackground(rounded(CANVAS, 13));
        form.addView(categoryPicker, new LinearLayout.LayoutParams(-1, dp(48)));
        categoryPicker.setOnClickListener(view -> new AlertDialog.Builder(this)
                .setTitle("Pilih kategori")
                .setItems(categories, (dialog, which) -> {
                    selectedCategory[0] = categories[which];
                    categoryPicker.setText("Kategori  ·  " + selectedCategory[0] + "  ▾");
                })
                .show());

        Calendar selectedDate = Calendar.getInstance();
        if (existing != null) {
            selectedDate.setTimeInMillis(existing.dateMillis);
        }
        TextView datePicker = text("Tanggal  ·  " + formatLongDate(selectedDate.getTimeInMillis())
                + "  ▾", 13, INK, false);
        datePicker.setGravity(Gravity.CENTER_VERTICAL);
        datePicker.setPadding(dp(13), 0, dp(13), 0);
        datePicker.setBackground(rounded(CANVAS, 13));
        LinearLayout.LayoutParams dateParams = new LinearLayout.LayoutParams(-1, dp(48));
        dateParams.topMargin = dp(8);
        form.addView(datePicker, dateParams);
        datePicker.setOnClickListener(view -> {
            Calendar current = (Calendar) selectedDate.clone();
            new DatePickerDialog(this, (picker, year, month, day) -> {
                selectedDate.set(year, month, day);
                datePicker.setText("Tanggal  ·  "
                        + formatLongDate(selectedDate.getTimeInMillis()) + "  ▾");
            }, current.get(Calendar.YEAR), current.get(Calendar.MONTH),
                    current.get(Calendar.DAY_OF_MONTH)).show();
        });

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Catat transaksi" : "Ubah transaksi")
                .setView(form)
                .setNegativeButton("Batal", null)
                .setPositiveButton(existing == null ? "Simpan" : "Perbarui", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    String title = titleInput.getText().toString().trim();
                    String amountText = amountInput.getText().toString().trim();
                    long amount;
                    try {
                        amount = Long.parseLong(amountText);
                    } catch (NumberFormatException exception) {
                        amount = 0;
                    }
                    if (title.isEmpty() || amount <= 0) {
                        Toast.makeText(this, "Isi nama dan jumlah yang valid.", Toast.LENGTH_SHORT)
                                .show();
                        return;
                    }

                    Transaction transaction = new Transaction(
                            existing == null ? UUID.randomUUID().toString() : existing.id,
                            title, selectedCategory[0], amount, selectedDate.getTimeInMillis(),
                            income[0]);
                    if (existing != null) {
                        transactions.remove(existing);
                    }
                    transactions.add(transaction);
                    if (!persistTransactions()) {
                        transactions.remove(transaction);
                        if (existing != null) {
                            transactions.add(existing);
                        }
                        return;
                    }
                    dialog.dismiss();
                    renderDashboard();
                    if (!income[0] && budget > 0 && monthlyExpenses() > budget) {
                        new AlertDialog.Builder(this)
                                .setTitle("Anggaran terlampaui")
                                .setMessage("Pengeluaran bulan ini sudah melewati anggaran yang kamu tetapkan.")
                                .setPositiveButton("Mengerti", null)
                                .show();
                    }
                }));
        dialog.show();
    }

    private void showBudgetDialog() {
        EditText input = input("Contoh: 2000000",
                InputType.TYPE_CLASS_NUMBER);
        if (budget > 0) {
            input.setText(String.valueOf(budget));
        }
        new AlertDialog.Builder(this)
                .setTitle("Anggaran bulanan")
                .setMessage("Tentukan batas pengeluaran untuk bulan ini.")
                .setView(input)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Simpan", (dialog, which) -> {
                    String value = input.getText().toString().trim();
                    try {
                        long nextBudget = Long.parseLong(value);
                        if (nextBudget <= 0) {
                            throw new NumberFormatException();
                        }
                        storage.saveBudget(nextBudget);
                        budget = nextBudget;
                        renderDashboard();
                    } catch (NumberFormatException exception) {
                        Toast.makeText(this, "Masukkan anggaran yang valid.",
                                Toast.LENGTH_SHORT).show();
                    } catch (IllegalStateException exception) {
                        Toast.makeText(this, exception.getMessage(), Toast.LENGTH_LONG).show();
                    }
                })
                .show();
    }

    private void exportTransactions() {
        List<Transaction> sorted = new ArrayList<>(transactions);
        Collections.sort(sorted, Comparator.comparingLong(transaction -> transaction.dateMillis));
        StringBuilder csv = new StringBuilder("Tanggal,Nama,Kategori,Jenis,Jumlah (Rp)\n");
        for (Transaction transaction : sorted) {
            csv.append(csvField(transaction.formattedDate())).append(',')
                    .append(csvField(transaction.title)).append(',')
                    .append(csvField(transaction.category)).append(',')
                    .append(transaction.income ? "Pemasukan" : "Pengeluaran").append(',')
                    .append(transaction.amount).append('\n');
        }
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/csv");
        share.putExtra(Intent.EXTRA_SUBJECT, "Catatan keuangan Saku Harian");
        share.putExtra(Intent.EXTRA_TEXT, csv.toString());
        startActivity(Intent.createChooser(share, "Ekspor catatan keuangan"));
    }

    private void deleteTransaction(Transaction transaction) {
        transactions.remove(transaction);
        if (!persistTransactions()) {
            transactions.add(transaction);
            return;
        }
        renderDashboard();
    }

    private boolean persistTransactions() {
        try {
            storage.saveTransactions(transactions);
            return true;
        } catch (JSONException | IllegalStateException exception) {
            Toast.makeText(this, "Perubahan transaksi gagal disimpan.",
                    Toast.LENGTH_LONG).show();
            return false;
        }
    }

    private long monthlyExpenses() {
        return monthlyTotal(false);
    }

    private long monthlyIncome() {
        return monthlyTotal(true);
    }

    private long monthlyTotal(boolean income) {
        Calendar start = Calendar.getInstance();
        start.set(Calendar.DAY_OF_MONTH, 1);
        start.set(Calendar.HOUR_OF_DAY, 0);
        start.set(Calendar.MINUTE, 0);
        start.set(Calendar.SECOND, 0);
        start.set(Calendar.MILLISECOND, 0);
        long monthStart = start.getTimeInMillis();
        Calendar end = (Calendar) start.clone();
        end.add(Calendar.MONTH, 1);
        long nextMonthStart = end.getTimeInMillis();
        long total = 0;
        for (Transaction transaction : transactions) {
            if (transaction.income == income && transaction.dateMillis >= monthStart
                    && transaction.dateMillis < nextMonthStart) {
                total += transaction.amount;
            }
        }
        return total;
    }

    private long[] lastSevenDaysExpenses() {
        long[] totals = new long[7];
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);
        for (int index = 0; index < totals.length; index++) {
            Calendar day = (Calendar) today.clone();
            day.add(Calendar.DAY_OF_YEAR, index - 6);
            long dayStart = day.getTimeInMillis();
            day.add(Calendar.DAY_OF_YEAR, 1);
            long nextDayStart = day.getTimeInMillis();
            for (Transaction transaction : transactions) {
                if (!transaction.income && transaction.dateMillis >= dayStart
                        && transaction.dateMillis < nextDayStart) {
                    totals[index] += transaction.amount;
                }
            }
        }
        return totals;
    }

    private Button typeButton(String label, boolean active) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(12);
        button.setPadding(0, 0, 0, 0);
        styleTypeButton(button, active);
        return button;
    }

    private void styleTypeButton(Button button, boolean active) {
        button.setTextColor(active ? WHITE : MUTED);
        button.setBackground(rounded(active ? GREEN : CANVAS, 14));
    }

    private EditText input(String hint, int inputType) {
        EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setTextSize(14);
        field.setHint(hint);
        field.setInputType(inputType);
        field.setPadding(dp(13), 0, dp(13), 0);
        field.setBackground(rounded(CANVAS, 13));
        return field;
    }

    private void addFormField(LinearLayout form, String label, EditText field) {
        TextView caption = text(label, 11, MUTED, true);
        LinearLayout.LayoutParams captionParams = params(-2, -2);
        captionParams.topMargin = dp(12);
        captionParams.bottomMargin = dp(5);
        form.addView(caption, captionParams);
        form.addView(field, new LinearLayout.LayoutParams(-1, dp(48)));
    }

    private String categoryIcon(String category) {
        switch (category) {
            case "Makanan":
                return "◉";
            case "Transportasi":
                return "↗";
            case "Belanja":
                return "▣";
            case "Tagihan":
                return "≡";
            default:
                return "✳";
        }
    }

    private String formatCurrency(long amount) {
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
        format.setMaximumFractionDigits(0);
        format.setMinimumFractionDigits(0);
        return format.format(amount);
    }

    private String formatCompactCurrency(long amount) {
        if (amount >= 1_000_000) {
            return "Rp" + compactNumber(amount / 1_000_000.0) + " jt";
        }
        if (amount >= 10_000) {
            return "Rp" + compactNumber(amount / 1_000.0) + " rb";
        }
        NumberFormat format = NumberFormat.getNumberInstance(new Locale("id", "ID"));
        format.setMaximumFractionDigits(0);
        return "Rp" + format.format(amount);
    }

    private String compactNumber(double value) {
        NumberFormat format = NumberFormat.getNumberInstance(new Locale("id", "ID"));
        format.setMaximumFractionDigits(value < 10 ? 1 : 0);
        return format.format(value);
    }

    private String formatLongDate(long millis) {
        return new SimpleDateFormat("d MMM yyyy", new Locale("id", "ID"))
                .format(new Date(millis));
    }

    private String csvField(String value) {
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        if (bold) {
            text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        }
        text.setGravity(Gravity.CENTER_VERTICAL);
        return text;
    }

    private LinearLayout.LayoutParams params(int width, int height) {
        return new LinearLayout.LayoutParams(
                width < 0 ? width : dp(width), height < 0 ? height : dp(height));
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radius));
        return shape;
    }

    private GradientDrawable circle(int color) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setShape(GradientDrawable.OVAL);
        return shape;
    }

    private GradientDrawable pill(int color) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(100));
        return shape;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
