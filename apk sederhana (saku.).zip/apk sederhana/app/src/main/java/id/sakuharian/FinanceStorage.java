package id.sakuharian;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

final class FinanceStorage {
    private static final String PREFERENCES = "saku_harian";
    private static final String TRANSACTIONS_KEY = "transactions";
    private static final String BUDGET_KEY = "monthly_budget";
    private final SharedPreferences preferences;

    FinanceStorage(Context context) {
        preferences = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE);
    }

    List<Transaction> loadTransactions() throws JSONException {
        List<Transaction> transactions = new ArrayList<>();
        JSONArray entries = new JSONArray(preferences.getString(TRANSACTIONS_KEY, "[]"));
        for (int index = 0; index < entries.length(); index++) {
            transactions.add(Transaction.fromJson(entries.getJSONObject(index)));
        }
        return transactions;
    }

    void saveTransactions(List<Transaction> transactions) throws JSONException {
        JSONArray entries = new JSONArray();
        for (Transaction transaction : transactions) {
            entries.put(transaction.toJson());
        }
        if (!preferences.edit().putString(TRANSACTIONS_KEY, entries.toString()).commit()) {
            throw new IllegalStateException("Transaksi tidak dapat disimpan ke perangkat.");
        }
    }

    long loadBudget() {
        return preferences.getLong(BUDGET_KEY, 0L);
    }

    void saveBudget(long budget) {
        if (!preferences.edit().putLong(BUDGET_KEY, budget).commit()) {
            throw new IllegalStateException("Anggaran tidak dapat disimpan ke perangkat.");
        }
    }
}
