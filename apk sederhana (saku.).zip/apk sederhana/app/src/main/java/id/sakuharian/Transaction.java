package id.sakuharian;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class Transaction {
    final String id;
    final String title;
    final String category;
    final long amount;
    final long dateMillis;
    final boolean income;

    Transaction(String id, String title, String category, long amount, long dateMillis, boolean income) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.amount = amount;
        this.dateMillis = dateMillis;
        this.income = income;
    }

    JSONObject toJson() throws JSONException {
        JSONObject json = new JSONObject();
        json.put("id", id);
        json.put("title", title);
        json.put("category", category);
        json.put("amount", amount);
        json.put("date", dateMillis);
        json.put("income", income);
        return json;
    }

    static Transaction fromJson(JSONObject json) throws JSONException {
        return new Transaction(
                json.getString("id"),
                json.getString("title"),
                json.getString("category"),
                json.getLong("amount"),
                json.getLong("date"),
                json.getBoolean("income")
        );
    }

    String formattedDate() {
        return new SimpleDateFormat("d MMM yyyy", new Locale("id", "ID"))
                .format(new Date(dateMillis));
    }
}
